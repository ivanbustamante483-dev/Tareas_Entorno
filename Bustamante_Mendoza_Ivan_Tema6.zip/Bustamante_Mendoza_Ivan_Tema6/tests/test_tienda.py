import pytest
import json
from unittest.mock import patch, mock_open, ANY
from tienda import (
    obtener_producto,
    calcular_subtotal,
    aplicar_descuento,
    calcular_envio,
    calcular_total,
    consultar_estado_envio,
    guardar_pedido,
    cargar_pedido,
    ProductoNoDisponibleError,
    PedidoInvalidoError
)

# 3. Usar al menos una fixture
@pytest.fixture
def pedido_valido():
    """Fixture que devuelve un pedido con productos existentes y cantidades válidas."""
    return [
        {"producto": "teclado", "cantidad": 1},
        {"producto": "raton", "cantidad": 2}
    ]

@pytest.fixture
def pedido_varias_lineas():
    """Fixture con varias líneas de pedido."""
    return [
        {"producto": "teclado", "cantidad": 1},
        {"producto": "raton", "cantidad": 1},
        {"producto": "usb", "cantidad": 5}
    ]

# 2. Diseñar pruebas unitarias básicas
def test_obtener_producto_normal():
    producto = obtener_producto("teclado")
    assert producto["precio"] == 25.0
    assert producto["stock"] == 10

def test_obtener_producto_inexistente():
    # 5. Probar excepciones
    with pytest.raises(KeyError):
        obtener_producto("producto_que_no_existe")

def test_calcular_subtotal_normal(pedido_valido):
    # teclado (25.0 * 1) + raton (15.0 * 2) = 25 + 30 = 55
    subtotal = calcular_subtotal(pedido_valido)
    assert subtotal == 55.0

# 4. Usar parametrización
@pytest.mark.parametrize("subtotal, es_vip, cupon, esperado", [
    (100, False, None, 100),       # Sin descuento
    (100, True, None, 90),         # VIP (10%)
    (100, False, "PROMO5", 95),    # Cupón 5%
    (100, False, "PROMO10", 90),   # Cupón 10%
    (100, True, "PROMO10", 80),    # VIP + Cupón 10% = 20%
    (100, True, "PROMO5", 85),     # VIP + Cupón 5% = 15%
    (100, True, "PROMO10", 80),    # Máximo 20% (probando el límite)
])
def test_aplicar_descuento_parametrizado(subtotal, es_vip, cupon, esperado):
    assert aplicar_descuento(subtotal, es_vip, cupon) == esperado

@pytest.mark.parametrize("subtotal, provincia, urgente, esperado", [
    (50, "Madrid", False, 6.5),    # Estándar < 100
    (150, "Madrid", False, 0),     # Gratis >= 100
    (50, "Baleares", False, 14.5), # Baleares (6.5 + 8)
    (50, "Canarias", True, 19.5),  # Canarias urgente (6.5 + 8 + 5)
    (120, "Canarias", False, 8),   # Gratis >= 100 + Plus Canarias (0 + 8)
    (120, "Canarias", True, 13),   # Gratis >= 100 + Canarias + Urgente (0 + 8 + 5)
])
def test_calcular_envio_parametrizado(subtotal, provincia, urgente, esperado):
    assert calcular_envio(subtotal, provincia, urgente) == esperado

def test_calcular_total_integracion(pedido_valido):
    # Subtotal = 55.0
    # Descuento (PROMO10) = 55 * 0.9 = 49.5
    # Envío (Madrid, urgente) = 6.5 + 5 = 11.5
    # Total = 49.5 + 11.5 = 61.0
    total = calcular_total(pedido_valido, "Madrid", cupon="PROMO10", urgente=True)
    assert total == 61.0

# 5. Probar excepciones
def test_pedido_vacio_raises_error():
    with pytest.raises(PedidoInvalidoError, match="El pedido no puede estar vacío"):
        calcular_subtotal([])

def test_cantidad_invalida_raises_error():
    with pytest.raises(PedidoInvalidoError, match="La cantidad debe ser mayor que cero"):
        calcular_subtotal([{"producto": "teclado", "cantidad": 0}])

def test_stock_insuficiente_raises_error():
    with pytest.raises(ProductoNoDisponibleError, match="Stock insuficiente"):
        calcular_subtotal([{"producto": "monitor", "cantidad": 10}]) # Stock es 5

# 6. Usar mocking
# Opción A: Simular consultar_estado_envio
def test_consultar_estado_envio_ok():
    resultado = consultar_estado_envio("OK123")
    assert resultado["estado"] == "en reparto"
    assert resultado["incidencia"] is False

def test_consultar_estado_envio_error():
    resultado = consultar_estado_envio("ERR456")
    assert resultado["estado"] == "desconocido"
    assert resultado["incidencia"] is True

def test_consultar_estado_envio_connection_error():
    with pytest.raises(ConnectionError):
        consultar_estado_envio("INVALID")

# Ejemplo de Mocking (Opción B: Simular apertura de fichero)
def test_guardar_pedido_mocking():
    pedido = {"test": "data"}
    m = mock_open()
    with patch("builtins.open", m):
        with patch("json.dump") as mock_json_dump:
            resultado = guardar_pedido("dummy_path.json", pedido)
            assert resultado is True
            m.assert_called_once_with(ANY, "w", encoding="utf-8")
            mock_json_dump.assert_called_once()

def test_cargar_pedido_mocking():
    pedido_mock = {"item": "valor"}
    m = mock_open(read_data=json.dumps(pedido_mock))
    with patch("builtins.open", m):
        with patch("json.load", return_value=pedido_mock):
            resultado = cargar_pedido("dummy_path.json")
            assert resultado == pedido_mock

# Casos límite (Boundary cases)
def test_calcular_subtotal_varias_lineas(pedido_varias_lineas):
    # teclado (25.0 * 1) + raton (15.0 * 1) + usb (8.0 * 5) = 25 + 15 + 40 = 80
    assert calcular_subtotal(pedido_varias_lineas) == 80.0

def test_aplicar_descuento_maximo():
    # Caso donde VIP (10%) + PROMO10 (10%) = 20%
    assert aplicar_descuento(100, es_vip=True, cupon="PROMO10") == 80.0
    # Caso donde intentamos superar el 20% (aunque el código lo capado)
    # Si hubiera otra promo, lo probaríamos. Aquí el código ya limita a 0.20.
